library(dplyr); library(lubridate)
## Set your working directory in following line
setwd("C:/Users/fatima/Desktop/Assignment")
df <- read.csv("data.csv")


# Explore Data ------------------------------------------------------------
summary(df)

# Wrangle Data ------------------------------------------------------------
df_modified <- df %>%  filter(Quantity > 0 , UnitPrice > 0 , !is.na(CustomerID))

summary(df_modified)

df_modified$InvoiceDate <- as.POSIXlt(df_modified$InvoiceDate,  
                                      format= "%m/%d/%Y %H:%M")

# Split week, month, and year into new columns

df_modified$week <- lubridate::week(ymd_hms(df_modified$InvoiceDate))
df_modified$month <- lubridate::month(ymd_hms(df_modified$InvoiceDate),label = TRUE)
df_modified$year <- lubridate::year(ymd_hms(df_modified$InvoiceDate))

write.csv(df_modified, "data_modified.csv", row.names = FALSE)


# Q1: Number of Transactions ----------------------------------------------

# Annual
annual_transaction <- df_modified %>% filter(year!= '2010') %>% 
            distinct(InvoiceNo)
            # count()# Total Transactions per invoice

# Monthly
monthly_transaction <- df_modified %>% filter(year!= '2010') %>% 
                    group_by(month) %>% distinct(InvoiceNo) %>% 
                    count() # Total Transactions per invoice

names(monthly_transaction)[2] <- "monthly_transactions"

# Weekly
weekly_transaction <- df_modified %>% filter(year!= '2010') %>% 
                        group_by(week) %>% distinct(InvoiceNo) %>% 
                        count() # Total Transactions per invoice

names(weekly_transaction)[2] <- "weekly_transactions"

write.csv(annual_transaction, "annual_transaction.csv", row.names = FALSE)
write.csv(monthly_transaction, "monthly_transaction.csv", row.names = FALSE)
write.csv(weekly_transaction, "weekly_transaction.csv", row.names = FALSE)


# Q2: No. of Active Clients (New or Recurrent) ----------------------------

customer_status <- df_modified %>% 
              distinct(InvoiceNo, CustomerID, month, week) %>% 
              count(CustomerID,  month, week)

customer_status$n[customer_status$n > 1] <- "Recurrent"
customer_status$n[customer_status$n == 1] <- "New"
names(customer_status)[names(customer_status) == "n"] <- "Client"

# Annual 
table(customer_status$Client)

# Monthly
table(customer_status$month, customer_status$Client)

# Weekly
table(customer_status$week, customer_status$Client)

write.csv(customer_status, "customer_status.csv", row.names = FALSE)


# Q3: Churn Rate (Weekly, Monthly, and Annually) --------------------------

monthly <- df_modified %>% 
  group_by(year, month) %>% 
  summarize(total_month=n_distinct(CustomerID))

monthly_max <- df_modified %>% 
  group_by(CustomerID) %>% 
  filter(InvoiceDate==max(InvoiceDate)) %>% 
  select(CustomerID, InvoiceDate, month, year) %>% 
  group_by(year, month) %>% 
  summarize(total_month=n_distinct(CustomerID))

month_churn <- merge(monthly, monthly_max, by=c('year', 'month'))
month_churn <- setNames(month_churn, c("year","month","total", "max"))

## Weekly

weekly <- df_modified %>% 
  group_by(year, week) %>% 
  dplyr::summarise(total_month=n_distinct(CustomerID))

weekly_max <- df_modified %>% 
  group_by(CustomerID) %>% 
  filter(InvoiceDate==max(InvoiceDate)) %>% 
  select(CustomerID, InvoiceDate, week, year) %>% 
  group_by(year, week) %>% 
  summarize(total_month=n_distinct(CustomerID))

week_churn <- merge(weekly, weekly_max, by=c('year', 'week'))
week_churn <- setNames(week_churn, c("year","week","total", "max"))

write.csv(week_churn, "week_churn.csv", row.names = FALSE)
write.csv(month_churn, "month_churn.csv", row.names = FALSE)

# Annual rate "estimated"
annual_churn <- filter(month_churn, month != "Dec")
annual <- round(( (mean(annual_churn$max)*12)/sum(month_churn_rate$total) )*100,2)

# Monthly
month_churn_rate <- read.csv("month_churn_rate.csv")

# WeeKly
week_churn_rate <- read.csv("week_churn_rate.csv")


# Note --------------------------------------------------------------------
# Regarding the “churn rate” calculation, 
# due to lack of information about previous years. 
# The annual rate was calculated by using the average losses per month.
# 
# As for the monthly & weekly rate,
# I used the available date to get an estimate of the lost customers 
# by gathering the last contact date for each customer.
# 
# N.B. the churn rates were calculated externally 
# in two separate csv file “month_churn” and “week_churn” . 
# The file results were renamed “month_churn_rate” and “week_churn_rate”,
# respectively.

